YAPE DETECTOR - PROYECTO MODIFICADO

Cambios hechos:
1) La app ya no manda GET a demo.pexcreative.com.
2) Ahora envia POST JSON a:
   https://panel.mrgarabato.com/Auth/pay/yape_notification_webhook.php
3) Envia header:
   X-Yape-Token: CAMBIA_ESTE_TOKEN_SEGURO_2026
4) Solo escucha notificaciones de Yape:
   com.bcp.innovacxion.yapeapp
5) Se incluyo un PHP base:
   server_php/Auth/pay/yape_notification_webhook.php

IMPORTANTE:
- Cambia CAMBIA_ESTE_TOKEN_SEGURO_2026 en Kotlin y PHP por el mismo token secreto.
- El APK no esta compilado aqui porque este entorno no tiene Gradle/Android SDK ni internet para descargarlo.
- Para compilar abre APK/NotificationReader2 en Android Studio y genera APK desde Build > Build APK(s).
