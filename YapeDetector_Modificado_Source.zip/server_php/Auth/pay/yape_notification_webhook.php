<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', '0');
error_reporting(E_ALL);
date_default_timezone_set('America/Lima');

$TOKEN = 'CAMBIA_ESTE_TOKEN_SEGURO_2026';
$LOG_FILE = __DIR__ . '/../storage/payments/yape_notifications_log.json';

function json_response(array $data, int $code = 200): void
{
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function read_json(string $file, array $default = []): array
{
    if (!is_file($file)) return $default;
    $raw = file_get_contents($file);
    if ($raw === false || trim($raw) === '') return $default;
    $json = json_decode($raw, true);
    return is_array($json) ? $json : $default;
}

function write_json_locked(string $file, array $data): void
{
    $dir = dirname($file);
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $fp = fopen($file, 'c+');
    if (!$fp) throw new RuntimeException('No se pudo abrir storage JSON.');
    try {
        if (!flock($fp, LOCK_EX)) throw new RuntimeException('No se pudo bloquear storage JSON.');
        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        fflush($fp);
        flock($fp, LOCK_UN);
    } finally {
        fclose($fp);
    }
}

function header_token(): string
{
    return (string)($_SERVER['HTTP_X_YAPE_TOKEN'] ?? '');
}

function extract_amount(string $text): ?float
{
    $patterns = [
        '/S\/?\s*([0-9]+(?:[\.,][0-9]{1,2})?)/i',
        '/soles?\s*([0-9]+(?:[\.,][0-9]{1,2})?)/i',
        '/([0-9]+(?:[\.,][0-9]{1,2})?)\s*soles?/i',
    ];

    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $text, $m)) {
            return (float)str_replace(',', '.', $m[1]);
        }
    }

    return null;
}

try {
    if (!hash_equals($TOKEN, header_token())) {
        json_response(['ok' => false, 'message' => 'Unauthorized'], 401);
    }

    $raw = file_get_contents('php://input');
    $data = json_decode((string)$raw, true);

    if (!is_array($data)) {
        json_response(['ok' => false, 'message' => 'Invalid JSON'], 400);
    }

    $app = (string)($data['app'] ?? $data['package_name'] ?? '');
    $title = (string)($data['title'] ?? '');
    $message = (string)($data['message'] ?? '');
    $eventId = (string)($data['event_id'] ?? hash('sha256', $app . '|' . $title . '|' . $message . '|' . microtime(true)));

    if ($app !== 'com.bcp.innovacxion.yapeapp') {
        json_response(['ok' => true, 'ignored' => true, 'message' => 'App ignored']);
    }

    $fullText = trim($title . ' ' . $message);
    $amount = extract_amount($fullText);

    $logs = read_json($LOG_FILE, []);

    if (isset($logs[$eventId])) {
        json_response(['ok' => true, 'duplicate' => true, 'message' => 'Notification already received']);
    }

    $logs[$eventId] = [
        'received_at' => date('Y-m-d H:i:s'),
        'event_id' => $eventId,
        'app' => $app,
        'title' => $title,
        'message' => $message,
        'amount_detected' => $amount,
        'raw' => $data,
    ];

    if (count($logs) > 3000) {
        $logs = array_slice($logs, -3000, null, true);
    }

    write_json_locked($LOG_FILE, $logs);

    json_response([
        'ok' => true,
        'message' => 'Notification received',
        'event_id' => $eventId,
        'amount_detected' => $amount
    ]);

} catch (Throwable $e) {
    json_response([
        'ok' => false,
        'message' => 'Internal error'
    ], 500);
}
