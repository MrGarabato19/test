package com.example.notificationreader

import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

class NotificationService : NotificationListenerService() {

    companion object {
        private const val TAG = "YapeDetector"

        // CAMBIA este token tambien en tu PHP: yape_notification_webhook.php
        private const val WEBHOOK_TOKEN = "CAMBIA_ESTE_TOKEN_SEGURO_2026"

        // Endpoint de tu panel
        private const val WEBHOOK_URL = "https://panel.mrgarabato.com/Auth/pay/yape_notification_webhook.php"
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val packageName = sbn.packageName ?: return

        val supportedApps = listOf(
            "com.bcp.innovacxion.yapeapp"
        )

        if (packageName !in supportedApps) {
            return
        }

        val extras = sbn.notification.extras

        val title = extras.getCharSequence("android.title")?.toString()?.trim() ?: ""
        val text = extras.getCharSequence("android.text")?.toString()?.trim()
            ?: extras.getCharSequence("android.bigText")?.toString()?.trim()
            ?: ""

        val bigText = extras.getCharSequence("android.bigText")?.toString()?.trim() ?: ""
        val subText = extras.getCharSequence("android.subText")?.toString()?.trim() ?: ""
        val infoText = extras.getCharSequence("android.infoText")?.toString()?.trim() ?: ""

        val message = when {
            bigText.isNotEmpty() -> bigText
            text.isNotEmpty() -> text
            else -> ""
        }

        if (title.isEmpty() && message.isEmpty()) {
            return
        }

        Log.d(TAG, "Notification: $packageName | $title | $message")

        sendToAPI(
            packageName = packageName,
            title = title,
            message = message,
            text = text,
            bigText = bigText,
            subText = subText,
            infoText = infoText,
            postTime = sbn.postTime
        )
    }

    private fun sendToAPI(
        packageName: String,
        title: String,
        message: String,
        text: String,
        bigText: String,
        subText: String,
        infoText: String,
        postTime: Long
    ) {
        Thread {
            var connection: HttpURLConnection? = null

            try {
                val eventId = sha256("$packageName|$title|$message|$postTime")

                val payload = JSONObject().apply {
                    put("event_id", eventId)
                    put("app", packageName)
                    put("package_name", packageName)
                    put("title", title)
                    put("message", message)
                    put("text", text)
                    put("big_text", bigText)
                    put("sub_text", subText)
                    put("info_text", infoText)
                    put("post_time", postTime)
                    put("device_model", Build.MODEL ?: "")
                    put("device_brand", Build.BRAND ?: "")
                    put("android_version", Build.VERSION.RELEASE ?: "")
                }

                val url = URL(WEBHOOK_URL)
                connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.connectTimeout = 8000
                connection.readTimeout = 12000
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                connection.setRequestProperty("Accept", "application/json")
                connection.setRequestProperty("X-Yape-Token", WEBHOOK_TOKEN)

                OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { writer ->
                    writer.write(payload.toString())
                    writer.flush()
                }

                val responseCode = connection.responseCode
                val responseText = try {
                    if (responseCode in 200..299) {
                        connection.inputStream.bufferedReader().use { it.readText() }
                    } else {
                        connection.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
                    }
                } catch (_: Exception) {
                    ""
                }

                Log.d(TAG, "Webhook response: $responseCode | $responseText")

            } catch (e: Exception) {
                Log.e(TAG, "Webhook error: ${e.message}")
            } finally {
                connection?.disconnect()
            }
        }.start()
    }

    private fun sha256(value: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
